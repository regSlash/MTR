#include <iostream>
#include <math.h>

using namespace std;

int n = 4, m = 3;

double findMaxValue(double **, int);
double* findMaxInArray(double *);
double* findMinInArray(double *);
double criterionBayesian( double **, int);

int main()
{
    int i, j;
    double **f = new double *[n+1];
    for( i = 0; i < n+1; ++i)
        f[i] = new double[m+1];

    cout << "Enter  elements of matrix F: " << endl;
    for (int i = 0; i <= n; i++)
    {
        for (int j = 0; j <= m; j++)
        {
            cin >> f[i][j];
        }
    }
    cout << endl;

    double *b = new double [n+1];

    for( i = 0; i < n+1; ++i){
        b[i]= criterionBayesian(f, i);
        cout << "B" << i+1 << "= " << b[i] << "; ";
    }
    cout << endl;

    double *resultBayesian = new double [2];
    resultBayesian = findMaxInArray(b);
    cout << "According the criterion of Bayesian, the promotion system x" << resultBayesian[1] << " has the maximum income from the sale of goods" << endl;
    cout << endl;

    double *v = new double [n+1];
    for( i = 0; i < n+1; ++i){
        v[i]=findMaxValue(f,i);
        cout << "V" << i+1 << "= " << v[i] << "; ";
    }
    cout << endl;
    double *resultVald = new double [2];
    resultVald = findMinInArray(v);
    cout << "According the Vald-criterion(minmax), the promotion system x" << resultVald[1] << " has minimal risk " << endl;

    delete []f;
    delete []v;
    delete []b;
    delete []resultBayesian;
    delete []resultVald;
    return 0;
}

double findMaxValue(double **f, int k)
{
    double maxValue = f[k][0];
    for(int i = 1; i <= m; i++)
    {
        if(maxValue < f[k][i])
            maxValue = f[k][i];
    }
    return maxValue;
}

double* findMaxInArray(double *a)
{
    double *result = new double [2];
    result[0] = a[0];
    result[1] = 1;
    for(int i = 1; i <= n; i++)
    {
        if(result[0] < a[i])
         {
            result[0] = a[i];
            result[1] = i+1;
         }
    }
    return result;
}

double* findMinInArray(double *a)
{
    double *result = new double [2];
    result[0] = a[0];
    result[1] = 1;
    for(int i = 1; i <= n; i++)
    {
        if(result[0] > a[i])
         {
            result[0] = a[i];
            result[1] = i+1;
         }
    }
    return result;
}

double criterionBayesian( double **f, int k)
{
    double p = 1./4;
    double sum = 0;

    for(int i = 0; i <= n; i++)
    {
        sum += p * f[k][i];
    }
    return sum;
}
